# Spike Conventions

This initial spike follows choices explicitly required by the user; future spikes should reuse them where applicable.

## Stack

Python NumPy/SciPy for high-accuracy references; plain JavaScript and inline Plotly for offline interactive inspection.

## Structure

One numbered `.planning/spikes/NNN-name/` directory with schema, readable reference source, browser source, verification JSON, data exports, README, and findings. `.planning/spikes/MANIFEST.md` indexes the spike.

## Patterns

Write Given/When/Then checks before execution. Keep analytic and numerical outcomes distinct. Record all units, versions, tolerances, timestamps, run IDs, and hashes. A technical VALIDATED verdict does not imply empirical support for the underlying biological story.

## Tools and libraries

NumPy 2.2.6, SciPy 1.17.1, Plotly 7.1.0, Node 24.21.0, Chrome for Testing 154.0.8037.92 worked in this environment.
