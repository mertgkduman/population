# Spike Manifest

## Ideas

### deference-demography
Test the specified hypothetical two-state demographic mechanism across follower deference and maturation timescale. The spike yields analytic and numerical maps, a browser dashboard, and measured verification; it makes no historical adaptation claim.

**Requirements:**
- Hold private judgment, adult advice, resource constants, and initial composition fixed within a trait sweep.
- Keep exactly two demographic ODE states with irreversible maturation.
- Separate copying from weighted judgment and M0 from M1.
- Preserve negative, null, and boundary results.
- Provide a reproducible offline dashboard and source-backed data.

## Spikes

| # | Idea | Name | Type | Validates | Verdict | Tags |
|---|------|------|-----------|-----------|---------|------|
| 001 | deference-demography | deference-demography | standard | Given specified mechanisms, when d and tau vary, then analytic and numerical results agree and an offline dashboard exposes them | VALIDATED | numerical, demography, dashboard |
| 002 | signed-advice-drift | [v2](../../v2/) on `v2-advice-drift` | versioned sensitivity | Given signed adult advice-quality drift, when rates and traits vary, then finite-horizon trajectories and the offline dashboard agree with references | VALIDATED | numerical, demography, advice drift |
| 003 | time-coupled-copying | [v3](../../v3/) on `v3-time-coupled-copying` | versioned sensitivity | Given declining copying and increasing adult advice quality, when rates and traits vary, then finite-horizon trajectories and the offline dashboard agree with references | VALIDATED | numerical, demography, time-varying copying |
